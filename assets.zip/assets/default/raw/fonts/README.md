# 字体

* default.ttf 为缺省字体。

* default_full.ttf 为完整的字体，和text.txt一起用来生成default.data。这在不支持ttf字体的板子才需要。